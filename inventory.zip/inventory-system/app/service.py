import time, uuid, threading
from app.repository import *

lock = threading.Lock()
TTL = 300

def reserve_item(sku, qty):
    with lock:
        product = get_product(sku)
        if not product or product[3] < qty:
            return None

        update_inventory(sku, product[3] - qty)
        res_id = str(uuid.uuid4())
        expires = int(time.time()) + TTL

        create_reservation((res_id, sku, qty, expires, "RESERVED"))
        return res_id

def confirm_reservation(res_id):
    res = get_reservation(res_id)
    if not res:
        return "INVALID"

    update_reservation_status(res_id, "CONFIRMED")
    return "CONFIRMED"

def cancel_reservation(res_id):
    res = get_reservation(res_id)
    if not res or res[4] != "RESERVED":
        return

    product = get_product(res[1])
    update_inventory(res[1], product[3] + res[2])
    update_reservation_status(res_id, "CANCELLED")
