from app.database import conn, cursor

def get_all_products():
    cursor.execute("SELECT * FROM inventory")
    return cursor.fetchall()

def reduce_stock(sku):
    cursor.execute(
        "UPDATE inventory SET available = available - 1 WHERE sku=? AND available > 0",
        (sku,)
    )
    conn.commit()
