import sqlite3
from app.seed_data import PRODUCTS

conn = sqlite3.connect("inventory.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS inventory (
    sku TEXT PRIMARY KEY,
    product_name TEXT,
    price INTEGER,
    available INTEGER
)
""")

# 🔁 AUTO SYNC DATA ON SERVER START
for p in PRODUCTS:
    cursor.execute("SELECT sku FROM inventory WHERE sku=?", (p["sku"],))
    exists = cursor.fetchone()

    if exists:
        cursor.execute("""
            UPDATE inventory
            SET product_name=?, price=?, available=?
            WHERE sku=?
        """, (p["name"], p["price"], p["stock"], p["sku"]))
    else:
        cursor.execute("""
            INSERT INTO inventory VALUES (?, ?, ?, ?)
        """, (p["sku"], p["name"], p["price"], p["stock"]))

conn.commit()
