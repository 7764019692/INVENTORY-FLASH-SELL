fetch("/products")
.then(res => res.json())
.then(data => {
    const container = document.getElementById("products");
    container.innerHTML = "";

    data.forEach(p => {
        const div = document.createElement("div");
        div.className = "card";
        div.innerHTML = `
            <h3>${p.name}</h3>
            <p class="price">₹${p.price}</p>
            <p class="stock">Only ${p.stock} left</p>
            <button class="buy" ${p.stock === 0 ? "disabled" : ""}>
                Buy Now
            </button>
        `;

        div.querySelector("button").onclick = () => {
            window.location.href = "/payment.html?sku=" + p.sku;
        };

        container.appendChild(div);
    });
});
