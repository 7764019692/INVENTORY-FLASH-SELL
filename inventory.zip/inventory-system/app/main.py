from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from app.repository import get_all_products, reduce_stock

app = FastAPI()

@app.get("/products")
def products():
    return [
        {"sku": p[0], "name": p[1], "price": p[2], "stock": p[3]}
        for p in get_all_products()
    ]

@app.post("/confirm-payment/{sku}")
def confirm_payment(sku: str):
    reduce_stock(sku)
    return {"status": "SUCCESS"}

app.mount("/", StaticFiles(directory="static", html=True), name="static")
