PRODUCTS = [
    {
        "sku": "IPH15",
        "name": "iPhone 15",
        "price": 79900,
        "stock": 3
    },
    {
        "sku": "REDMI13P",
        "name": "Redmi Note 13 Pro",
        "price": 25999,
        "stock": 5
    },
    {
        "sku": "VIVOT4",
        "name": "Vivo T4",
        "price": 19999,
        "stock": 4
    },
    {
        "sku": "VIVOT5",
        "name": "Vivo T5",
        "price": 22999,
        "stock": 6
    }
]
