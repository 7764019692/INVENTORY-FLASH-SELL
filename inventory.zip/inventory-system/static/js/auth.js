function login() {
    const name = document.getElementById("name").value;
    if (!name) {
        alert("Enter your name");
        return;
    }
    sessionStorage.setItem("user", name);
    window.location.href = "/";
}

function checkLogin() {
    if (!sessionStorage.getItem("user")) {
        window.location.href = "/login.html";
    }
}

function logout() {
    sessionStorage.clear();
    window.location.href = "/login.html";
}
