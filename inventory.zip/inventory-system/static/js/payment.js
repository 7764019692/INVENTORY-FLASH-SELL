const sku = new URLSearchParams(window.location.search).get("sku");

document.getElementById("product").innerText =
    "Pay for product: " + sku;

function showQR() {
    document.getElementById("qrSection").style.display = "block";
}

function confirmPayment() {
    fetch(`/confirm-payment/${sku}`, { method: "POST" })
        .then(() => {
            alert("✅ Payment confirmed!");
            window.location.href = "/";
        });
}

function cancel() {
    alert("❌ Payment cancelled");
    window.location.href = "/";
}
